package com.itw.dao;

import com.itw.domain.OrderItem;

public interface OrderItemDao {
    public int saveOrderItem(OrderItem orderItem);
}
