package com.itw.dao;

import com.itw.domain.User;

public interface UserDao {
    public User queryUserByAccount(String account);
    public User queryUserByAccountAndPassword(String account, String password);

    public int saveUser(User user);

    public User queryUserById(Integer id);
}
