package com.itw.dao;

public interface CartDao {
    //查询商品

    //从购物车中删除

    //遍历，商品显示在购物车
}
