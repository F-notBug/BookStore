package com.itw.dao;

import com.itw.domain.Order;

public interface OrderDao {
    public int saveOrder(Order order);
}
