package com.itw.dao.Impl;

import com.itw.dao.BaseDao;
import com.itw.dao.UserDao;
import com.itw.domain.User;

public class UserDaoImpl extends BaseDao implements UserDao {
    @Override
    public User queryUserByAccount(String account) {
        String sql = "select account from t_user where account=?";
        return queryForOne(User.class, sql,account);
    }

    public User queryUserByAccountAndPassword(String account, String password) {
        String sql="select * from t_user where account=? and password=?";
        return queryForOne(User.class,sql,account,password);
    }

    public User queryUserById(Integer id){
        String sql="select * from t_user where id=?";
        return queryForOne(User.class,sql,id);
    }

    /**
     * 注册
     * @param user
     * @return
     */
    public int saveUser(User user) {
        String sql = "insert into t_user(`username`,`account`,`password`,`address`)values(?,?,?,?)";
        return update(sql,user.getUsername(),user.getAccount(),user.getPassword(),user.getAddress());
    }


}
