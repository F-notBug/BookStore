package com.itw.dao;

import com.itw.domain.Admin;


public interface AdminDao {
    public Admin queryAdminByAdmin(String admin);
    public Admin queryAdminByAdminAndPassword(String admin, String password);
}
