package com.itw.dao.Impl;

import com.itw.dao.BaseDao;
import com.itw.dao.OrderDao;
import com.itw.dao.OrderItemDao;
import com.itw.domain.Order;
import com.itw.domain.OrderItem;

public class OrderItemDaoImpl extends BaseDao implements OrderItemDao {

    @Override
    public int saveOrderItem(OrderItem orderItem) {
        String sql = "insert into t_order_item(`name`,`count`,`price`,`total_Price`,`order_id`) values(?,?,?,?,?)";
        return update(sql,orderItem.getName(),orderItem.getCount(),orderItem.getPrice(),orderItem.getTotalPrice(),orderItem.getOrderId());
    }
}
