package com.itw.dao.Impl;

import com.itw.dao.AdminDao;
import com.itw.dao.BaseDao;
import com.itw.dao.BookDao;
import com.itw.domain.Admin;
import com.itw.domain.User;


public class AdminDaoImpl extends BaseDao implements AdminDao {
    @Override
    public Admin queryAdminByAdmin(String admin) {
        String sql = "select admin from t_admin where admin=?";
        return queryForOne(Admin.class, sql,admin);
    }

    @Override
    public Admin queryAdminByAdminAndPassword(String admin, String password) {
        String sql="select * from t_admin where admin=? and password=?";
        return queryForOne(Admin.class,sql,admin,password);
    }
}
