package com.itw.service;

import com.itw.domain.Admin;

public interface AdminService {
    public Admin loginAdmin(Admin admin);
}
