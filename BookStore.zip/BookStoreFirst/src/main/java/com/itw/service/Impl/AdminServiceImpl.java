package com.itw.service.Impl;

import com.itw.dao.AdminDao;
import com.itw.dao.Impl.AdminDaoImpl;
import com.itw.domain.Admin;
import com.itw.service.AdminService;

public class AdminServiceImpl implements AdminService {
    AdminDao adminDao = new AdminDaoImpl();
    @Override
    public Admin loginAdmin(Admin admin) {
        return adminDao.queryAdminByAdminAndPassword(admin.getAdmin(),admin.getPassword());
    }
}
