package com.itw.service.Impl;

import com.itw.dao.Impl.UserDaoImpl;
import com.itw.dao.UserDao;
import com.itw.domain.User;
import com.itw.service.UserService;

public class UserServiceImpl implements UserService {
    UserDao userDao = new UserDaoImpl();

    //用户登录
    public User loginUser(User user) {
        return userDao.queryUserByAccountAndPassword(user.getAccount(), user.getPassword());
    }

    public int registerUser(User user) {
        return userDao.saveUser(user);
    }

    public boolean existsAccount(String account) {
        if(userDao.queryUserByAccount(account)==null) {
            return false;
        }
        return true;
    }

    public User checkIdLoginService(Integer id) {
        return userDao.queryUserById(id);
    }
}
