package com.itw.service;

import com.itw.domain.User;

public interface UserService {
    public User loginUser(User user);

    public int registerUser(User user);

    public boolean existsAccount(String account);

    public User checkIdLoginService(Integer id);
}
