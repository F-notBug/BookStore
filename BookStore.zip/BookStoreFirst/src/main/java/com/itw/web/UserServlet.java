package com.itw.web;

import com.itw.domain.Admin;
import com.itw.domain.User;
import com.itw.service.AdminService;
import com.itw.service.Impl.AdminServiceImpl;
import com.itw.service.Impl.UserServiceImpl;
import com.itw.service.UserService;
import com.itw.utils.WebUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.google.code.kaptcha.Constants.KAPTCHA_SESSION_KEY;

@WebServlet(name = "UserServlet",urlPatterns = "/userServlet")
public class UserServlet extends BaseServlet {
    UserService userService = new UserServiceImpl();
    AdminService adminService = new AdminServiceImpl();
    //用户登录
    protected void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String username = req.getParameter("username");
        String account = req.getParameter("account");
        String password = req.getParameter("password");
        String address = req.getParameter("address");
        User user = userService.loginUser(new User(null, username, account, password,address));
        if (user==null){
            System.out.println("密码错误或者用户不存在");
            req.getRequestDispatcher("/pages/front/user/login.jsp").forward(req,resp);
        }else{
            System.out.println("登录成功");
//            Cookie c=new Cookie("id",user.getId()+"");
//            c.setMaxAge(3*24*3600);
//            c.setPath("/ckl");
//            resp.addCookie(c);

            req.getSession().setAttribute("user",user);
            req.getRequestDispatcher("index_2.jsp").forward(req,resp);
        }
    }
    //管理员登录
    protected void login_2(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String admin = req.getParameter("account");
        String password = req.getParameter("password");
        Admin user_2 = adminService.loginAdmin(new Admin(0,admin,password));
        if (user_2==null){
            System.out.println("密码错误或者管理员不存在");
            req.getRequestDispatcher("/pages/front/user/login.jsp").forward(req,resp);
        }else{
            System.out.println("管理员登录成功");
            req.getSession().setAttribute("user_2",user_2);
            req.getRequestDispatcher("pages/background/manager/manager.jsp").forward(req,resp);
        }
    }
    //用户退出
    protected void loginOut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getSession().invalidate();
        resp.sendRedirect(req.getContextPath()+"/index_2.jsp");

    }
    //管理员退出
    protected void loginOut_2(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getSession().invalidate();
        resp.sendRedirect(req.getContextPath()+"/index_2.jsp");
    }

    //用户注册
    protected void register(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        //获取session中的验证码
        String token = (String) req.getSession().getAttribute(KAPTCHA_SESSION_KEY);
        //删除session中的验证码
        req.getSession().removeAttribute(KAPTCHA_SESSION_KEY);
        //1、获取参数
        String username = req.getParameter("username");
        String account = req.getParameter("account");
        String password = req.getParameter("password");
        String address = req.getParameter("address");
        String code = req.getParameter("code");
        User user = (User) WebUtils.copyParamToBean(req.getParameterMap(),new User());
        //2、检测验证码是否正确  写死，验证码=password
        if(token!=null && token.equalsIgnoreCase(code)){
            if(userService.existsAccount(account)) {
                System.out.println("用户名["+account+"]已存在");
                //把回显信息放在Request域中
                req.setAttribute("msg","用户名已存在!!");
                req.setAttribute("username",username);
                req.setAttribute("password",password);
                req.setAttribute("address",address);
                req.getRequestDispatcher("/pages/front/user/register.jsp").forward(req,resp);
            }else {
                userService.registerUser(new User(null, username, account, password, address));
                req.getRequestDispatcher("/pages/front/user/register_success.jsp").forward(req, resp);
                System.out.println("mission success");
            }
        }else{
            //把回显信息放在Request域中
            req.setAttribute("msg","验证码错误!!");
            req.setAttribute("username",username);
            req.setAttribute("password",password);
            req.setAttribute("address",address);
            System.out.println("验证码["+code+"]错误");
            req.getRequestDispatcher("/pages/front/user/register.jsp").forward(req,resp);
        }
    }



}
