package com.itw.web;

import com.itw.domain.Book;
import com.itw.domain.Page;
import com.itw.service.BookService;
import com.itw.service.Impl.BookServiceImpl;
import com.itw.utils.WebUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "BookServlet",urlPatterns = "/bookServlet")
public class BookServlet extends BaseServlet{
    private BookService bookService = new BookServiceImpl();

    //分页
    protected void page(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int pageNo = WebUtils.parseInt(req.getParameter("pageNo"),1);
        int pageSize = WebUtils.parseInt(req.getParameter("pageSize"), Page.PAGE_SIZE);
        Page<Book> page = bookService.page(pageNo, pageSize);
        page.setUrl("bookServlet?action=page");
        req.setAttribute("page",page);
        req.getRequestDispatcher("pages/background/manager/book_manager.jsp").forward(req,resp);

    }

    //添加
    protected void add(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int pageNo = WebUtils.parseInt(req.getParameter("pageNo"),0);
        pageNo+=1;
        Book book = (Book) WebUtils.copyParamToBean(req.getParameterMap(), new Book());
        bookService.addBook(book);
        resp.sendRedirect(req.getContextPath()+"/bookServlet?action=page&pageNo="+pageNo);
    }

    //删除
    protected void delete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = WebUtils.parseInt(req.getParameter("id"), 0);
        bookService.deleteBookById(id);
        resp.sendRedirect(req.getContextPath()+"/bookServlet?action=page&pageNo="+req.getParameter("pageNo"));
    }

    //获取图书
    protected void getBook(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = WebUtils.parseInt(req.getParameter("id"),0);
        Book book = bookService.queryBookById(id);
        req.setAttribute("book",book);
        req.getRequestDispatcher("/pages/background/manager/book_edit.jsp").forward(req,resp);
    }

    //修改
    protected void update(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Book book = (Book) WebUtils.copyParamToBean(req.getParameterMap(),new Book());
        bookService.updateBook(book);
        resp.sendRedirect(req.getContextPath()+"/bookServlet?action=page&pageNo="+req.getParameter("pageNo"));
    }

    //遍历查询
    protected void list(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1、通过BookService查询全部图书
        List<Book> books = bookService.queryBookList();
        //2、把全部图书保存到Request域中
        req.setAttribute("books", books);
        //3、请求转发到jsp页面
        req.getRequestDispatcher("/pages/background/manager/book_manager.jsp").forward(req,resp);
    }
}
