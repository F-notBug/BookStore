package com.itw.web;

import com.itw.domain.User;
import com.itw.service.Impl.UserServiceImpl;
import com.itw.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns = "/ckl")
public class CookieLoginServlet extends BaseServlet{
    protected void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        //设置请求和响应编码格式
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        //定义Cookie数组，获取Cookie信息
        Cookie[] cks=req.getCookies();
        //处理请求信息：如果cks不空则进行免登录处理，如果cks为空那么请求转发给page注册页面
        if(cks!=null){
            //遍历Cookie信息
            String id="";
            for(Cookie k:cks){
                //如果cookie的键名是“uid”，则获取键值赋给uid1
                if("id".equals(k.getName())){
                    id=k.getValue();
                }
            }
            //如果所获取到的键值id是空，直接进行请求转发到page页面
            if("".equals(id)){
                //请求转发
                req.getRequestDispatcher("/pages/front/user/login.jsp").forward(req, resp);
                return;
            }else{
                //校验uid1用户信息(由于主键的唯一性，Cookie中存储的是id)
                //声明业务层对象
                UserService ls=new UserServiceImpl();
                //实例化业务层对象方法
                User u=ls.checkIdLoginService(Integer.valueOf(id));
                //判断根据uid1查出来的u是否为空，
                //不空说明存在这个用户，Cookie免登录成功，重定向到main页面
                //u为空说明不存在这个用户，请求转发到page页面
                if(u!=null){
                    //重定向
                    resp.sendRedirect(req.getContextPath()+"/index_2.jsp");
                    return;
                }else{
                    //请求转发
                    req.getRequestDispatcher("/pages/front/user/login.jsp").forward(req, resp);
                    return;
                }
            }
        }else{
            //请求转发
            req.getRequestDispatcher("/pages/front/user/login.jsp").forward(req, resp);
            return;
        }
    }
}
