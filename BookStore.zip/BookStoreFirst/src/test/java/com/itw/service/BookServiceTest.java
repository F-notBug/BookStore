package com.itw.service;

import com.itw.domain.Page;
import com.itw.service.Impl.BookServiceImpl;
import junit.framework.TestCase;

public class BookServiceTest extends TestCase {

    BookService bookService = new BookServiceImpl();
    public void testPage() {
        System.out.println(bookService.page(1, Page.PAGE_SIZE));
    }
}