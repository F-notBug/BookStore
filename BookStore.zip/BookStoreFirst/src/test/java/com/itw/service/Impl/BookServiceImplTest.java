package com.itw.service.Impl;

import com.itw.domain.Book;
import com.itw.service.BookService;
import junit.framework.TestCase;

import java.math.BigDecimal;

public class BookServiceImplTest extends TestCase {

    BookService bookService = new BookServiceImpl();
    public void testUpdateBook() {
        bookService.updateBook(new Book(1,"斗nima2", BigDecimal.valueOf(32),"bug",200,200,"1212"));
    }
}