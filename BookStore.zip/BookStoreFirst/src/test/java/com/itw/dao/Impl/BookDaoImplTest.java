package com.itw.dao.Impl;

import com.itw.dao.BookDao;
import com.itw.domain.Book;
import com.itw.domain.Page;
import junit.framework.TestCase;

import java.math.BigDecimal;

public class BookDaoImplTest extends TestCase {
    BookDao bookDao = new BookDaoImpl();

    public void testQueryBookById() {
        System.out.println(bookDao.queryBookById(1).toString());
    }

    public void testAddBook() {
        bookDao.addBook(new Book(null,"斗破苍穹", BigDecimal.valueOf(32),"bug",200,200,"1212"));
    }

    public void testDeleteBookById() {
    }

    public void testUpdateBook() {
        bookDao.updateBook(new Book(1,"斗nima", BigDecimal.valueOf(32),"bug",200,200,"1212"));
    }

    public void testQueryBooks() {
    }

    public void testQueryForPageTotalCount() {

        System.out.println(bookDao.queryForPageTotalCount());
    }

    public void testQueryForPageItems() {

        System.out.println(bookDao.queryForPageItems(0, Page.PAGE_SIZE).toString());
    }
}